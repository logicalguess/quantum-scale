import matplotlib.pyplot as plt
import math


def plot_bin_and_arrow(x0, y0, x, y, color, alpha=1, factor=0.5):
    plt.scatter(x0, y0, s=50, color=color)
    plt.arrow(x0 + factor*x, y0 - factor*y, x, -y, head_length=0, head_width=0, color=color, linewidth=5, alpha=alpha)


def plot_bin_and_arrow1(x0, y0, x, y, color, alpha, factor, label=''):
    plt.scatter(x0, y0, s=50, color=color, alpha=alpha)

    text_x = x0 - len(label) - 3 if x > 0 else x0 + 2
    plt.text(text_x, y0, label, fontsize=12, verticalalignment='center')

    plt.arrow(x0, y0, x*factor, -y*factor, head_length=0, head_width=0, width=0, color=color, linewidth=5, alpha=alpha)


def plot_state(bins, colors=None):
    plt.axis('off')
    plt.grid(False)

    n_qbits = math.log2(len(bins))
    plt.axis([-40, 60, 80 + 10*len(bins), 0])

    if colors is None:
        colors =['r', 'g', 'b', 'y', 'orange', 'm', 'c', 'purple']

    i = 0
    alpha = 0
    for b in bins:
        if i % 8 and i != 0:
            alpha = alpha + 1

        alpha = 1 - 0.25*alpha

        factor = 10*n_qbits if abs(bins[b].real) < 1 or abs(bins[b].imag) < 1 else n_qbits
        plot_bin_and_arrow1(10, 10 + 15*i, bins[b].real, bins[b].imag, colors[i % 8], alpha, factor, b)

        if i + 1 != len(bins):
            plt.arrow(10, 13 + 15*i, 0, 9, color='gray', width=0, linewidth=5, alpha=0.5)

        i = i + 1

    plt.show()


if __name__ == "__main__":

    # plt.axis([-10,140,90,-10])
    #
    # plt.axis('off')
    # plt.grid(False)
    #
    # plot_bin_and_arrow(10, 10, 6, 2.5, 'r')
    #
    # plt.arrow(10, 12, 0, 11, head_length=0, head_width=0, color='gray', alpha=0.5, linewidth=5)
    #
    # plot_bin_and_arrow(10, 25, -6, 3, 'g')
    #
    # plt.text(0, 50, 'Quantum State')
    #
    # plt.show()

    plot_state({'0': 3 + 5j, '1': -2 + 2j, '2': 4 - 7j, '3': -3 -3j})


