import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def cry(theta, qc, q_control, q_target):
    qc.ry(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def c_ry(qc, theta, ctrl, anc, tgt):
    return util.controlled(qc, ctrl, anc, tgt, c_gate = lambda qc, c, t: cry(theta, qc, c, t))


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            crz(-np.pi / float(2 ** (j - k)), qc, q[j], q[k])


def is_bit_set(m, k):
    return m & (1 << k)


def process(n_bits, c_bits, probs):
    for b, c in probs.items():
        input = int(b[0:n_bits], 2)
        output = int(b[n_bits:n_bits + c_bits], 2)
        print(input, " -> ", output)


def build_circuit(m, n_qbits, c_qbits):
    t = QuantumRegister(n_qbits)
    a = QuantumRegister(1)
    e = QuantumRegister(n_qbits)
    c = QuantumRegister(c_qbits)
    qc = QuantumCircuit(t, c, a, e)

    for i in range(n_qbits):
        if is_bit_set(m, i):
            qc.x(t[n_qbits - 1 - i])

    for i in range(c_qbits):
        qc.h(c[i])

    qc.rx(np.pi/2, a[0])
    qc.z(a[0])
    qc.x(a[0])

    # controlled rotations
    for i in range(c_qbits):
        c_ry(qc, 1/2**c_qbits * 2*np.pi* 2**(i+1)*4, [t[0], c[i]], e, a[0])
        c_ry(qc, 1/2**c_qbits * 2*np.pi* 2**(i+1)*4, [t[0], t[1], c[i]], e, a[0])
        c_ry(qc, 1/2**c_qbits * 2*np.pi* 2**(i+1)*1, [t[1], c[i]], e, a[0])

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(c_qbits)])

    qc.rx(-np.pi/2, a[0])

    return qc


if __name__ == "__main__":
    n_tgt_bits = 2
    n_ctrl_bits = n_tgt_bits**2

    qc = build_circuit(3, n_tgt_bits, n_ctrl_bits)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    # print(probs)

    process(n_tgt_bits, n_ctrl_bits, probs)

    # 3  ->  9

