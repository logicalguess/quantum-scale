# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import math
import numpy as np

import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import util

# k = first 3 bits reversed
# |k>: sqrt(1/8)*(cos(k*theta) + i*sin(k*theta))

def cry(theta, qc, q_control, q_target):
    qc.ry(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta/2, q_target)
    qc.cx(q_control, q_target)

def crz(theta, qc, q_control, q_target):
    qc.rz(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta/2, q_target)
    qc.cx(q_control, q_target)


def qft(qc, q):
    for j in range(len(q)):
        qc.h(q[j])
        for k in range(j + 1, len(q)):
            qc.crz(np.pi/float(2**(k - j)), q[k], q[j])

def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            #qc.cu1(-np.pi/float(2**(j-k)), q[j], q[k])
            crz(-np.pi/float(2**(j-k)), qc, q[j], q[k])


def build_circuit(n_qbits, theta):
    q = QuantumRegister(n_qbits)
    a = QuantumRegister(1)
    qc = QuantumCircuit(q, a)


    # qc.h(q[0])
    # qc.h(q[1])
    # qc.h(q[2])

    for i in range(n_qbits):
        qc.h(q[i])

    qc.h(a[0])

    qft(qc, [q[i] for i in range(n_qbits)])

    # iqft(qc, [q[i] for i in range(n_qbits)])

    return qc, None, None


if __name__ == "__main__":

    theta = np.pi/2

    # state reversed
    f = np.empty(8, dtype=np.complex_)
    param = np.cos(theta) + 1j*np.sin(theta)
    for k in range(8):
        print(format(k, 'b').zfill(3)[::-1], f"-> sqrt(1/8)*(cos({k}*theta) + i*sin({k}*theta)) -> ", 1j*np.round(math.sqrt(1/8)*param**k, 5))

    qc, _, _ = build_circuit(3, theta)

    # from qiskit.tools.visualization import plot_circuit
    # plot_circuit(qc)

    hist = util.get_probs((qc, None, None), 'sim')
    print("Probabilities:", hist)

    visualization.plot_histogram(hist)
