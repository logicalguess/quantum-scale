import numpy as np

pi = np.pi


def f(t):
    return np.sin(2*pi*t) # 1 # t

if __name__ == "__main__":
    n_ctrl_bits = 10
    N = 2**n_ctrl_bits

    t = 0.3

    print("t = ", t)
    print("f(t) = ", np.round(f(t), 5)) # period 1

    ts = 1/N  # sampling period

    result = 0.0

    for k in range(N):
        d = t - k*ts
        coeff = np.sin(pi*d/ts)/np.sin(pi*d)/N
        result = result + f(k*ts)*coeff

    print("interpolated value = ", np.round(result, 5))

    # t =  0.3
    # f(t) =  0.95106
    # interpolated value =  0.95106

    # t =  0.123
    # f(t) =  0.69817
    # interpolated value =  0.69817
