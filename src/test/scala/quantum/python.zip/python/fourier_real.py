# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import math
import numpy as np

import util

pi = np.pi
cos = np.cos
sin = np.sin

# '0000': sqrt(1/8)
# '0001': 0
# '0010': sqrt(1/8)*cos(4*theta)
# '0011': sqrt(1/8)*sin(4*theta)
# '0100': sqrt(1/8)*cos(2*theta)
# '0101': sqrt(1/8)*sin(2*theta)
# '0110': sqrt(1/8)*cos(6*theta)
# '0111': sqrt(1/8)*sin(6*theta)
# '1000': sqrt(1/8)*cos(theta)
# '1001': sqrt(1/8)*sin(theta)
# '1010': sqrt(1/8)*cos(5*theta)
# '1011': sqrt(1/8)*sin(5*theta)
# '1100': sqrt(1/8)*cos(3*theta)
# '1101': sqrt(1/8)*sin(3*theta)
# '1110': sqrt(1/8)*cos(7*theta)
# '1111': sqrt(1/8)*sin(7*theta)

# k = first 3 bits reversed
# |k>|0>: sqrt(1/8)*cos(k*theta)
# |k>|1>: sqrt(1/8)*sin(k*theta)

def cry(theta, qc, q_control, q_target):
    qc.ry(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta/2, q_target)
    qc.cx(q_control, q_target)


def crz(theta, qc, q_control, q_target):
    qc.rz(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta/2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            qc.cu1(-np.pi/float(2**(j-k)), q[j], q[k])
            # crz(-np.pi/float(2**(j-k)), qc, q[j], q[k])


def build_circuit(n_qbits, theta):
    q = QuantumRegister(n_qbits)
    t = QuantumRegister(1)
    qc = QuantumCircuit(q, t)

    # qc.ry(theta, t[0])

    # qc.h(q[0])
    # qc.h(q[1])
    # qc.h(q[2])

    for i in range(n_qbits):
        qc.h(q[i])

    # cry(2*theta, qc, q[0], t[0])
    # cry(4*theta, qc, q[1], t[0])
    # cry(8*theta, qc, q[2], t[0])

    for i in range(n_qbits):
        cry(2**(i+1)*theta, qc, q[i], t[0])

    iqft(qc, [q[i] for i in range(n_qbits)])

    return qc, None, None


if __name__ == "__main__":
    N = 8

    t = 5.7
    theta = t*2*np.pi/N
    # theta = 2*np.arcsin(np.sqrt(0.3))

    # state reversed
    # for k in range(8):
    #     print(format(k, 'b').zfill(3)[::-1] + '0', f"-> sqrt(1/8)*cos({k}*theta) -> ", np.round(math.sqrt(1/8)*np.cos(k*theta), 5))
    #     print(format(k, 'b').zfill(3)[::-1] + '1', f"-> sqrt(1/8)*sin({k}*theta) -> ", np.round(math.sqrt(1/8)*np.sin(k*theta), 5))

    qc, _, _ = build_circuit(3, theta)

    # from qiskit.tools.visualization import plot_circuit
    # plot_circuit(qc)

    state, hist = util.get_state_and_probs((qc, None, None), 'sim')
    print("Probabilities:", hist)

    # ########### fourier match

    state_c = np.empty(N, dtype=np.complex_)
    state_s = np.empty(N, dtype=np.complex_)

    # for i in range(N):
    #     key = format(i, 'b').zfill(3)
    #     state_c[i] = np.round(state.get(key[::-1] + '0'), 5)
    #     state_s[i] = np.round(state.get(key[::-1] + '1'), 5)

    for i in range(N):
        state_c[i] = np.round(math.sqrt(1/N)*cos(i*theta), 5)
        state_s[i] = np.round(math.sqrt(1/N)*sin(i*theta), 5)

    # print("state_c", state_c)
    # print("state_", state_s)

    for k in range(N):
        fourier = np.empty(N, dtype=np.complex_)
        root = cos(k*2*pi/N) + 1j*sin(k*2*pi/N)
        for i in range(N):
            fourier[i] = math.sqrt(1/N)*root**(i)

                # state
        print(k, " 0-> ", np.round(np.vdot(fourier, state_c), 5))
        print(k, " 1-> ", np.round(np.vdot(fourier, state_s), 5))

        # probabilities
        # print(k, " 0-> ", np.round(abs(np.vdot(state_c, fourier))**2, 5))
        # print(k, " 1-> ", np.round(abs(np.vdot(state_s, fourier))**2, 5))


    # visualization.plot_histogram(hist)
