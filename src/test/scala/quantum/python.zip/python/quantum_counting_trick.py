import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j):
            crz(-np.pi / 2 ** (j - k), qc, q[j], q[k])


# multiply by i
def cxyz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cy(q_control, q_target)
    qc.cx(q_control, q_target)

# multiply by -i
def cyxz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    qc.cy(q_control, q_target)


# multiply by -1
def cxzx(qc, q_control, q_target):
    qc.cx(q_control, q_target)
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    #qc.cz(q_control, q_target)


def crx(theta, qc, q_control, q_target):
    qc.rx(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rx(-theta / 2, q_target)
    qc.cx(q_control, q_target)


# multiply by -1
def crz2pi(qc, q_control, q_target):
    crz(2*np.pi, qc, q_control, q_target)

def cx(qc, q_control, q_target):
    qc.cx(q_control, q_target)

def is_bit_not_set(m, k):
    return not (m & (1 << k))


def on_match(n, m, gate, qc, c, q, e, a):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[i])

    util.controlled(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(len(q))], e, a, c_gate = lambda qc, ctrl, tgt: gate(qc, ctrl, tgt))

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[i])


def prepare_eigenvector(qbits, good, qc, t, e, a):
    # 1) multiply all states by i
    qc.z(a[0])
    qc.y(a[0])
    qc.x(a[0])
    # 2) multiply good states by -i
    for m in good:
        on_match(qbits, m, cyxz, qc, [], t, e, a)
        #on_match(qbits, m, crz2pi, qc, [], t, e, a)


def oracle(n, good, qc, c, q, e, a):
    for m in good:
        # on_match(n, m, crz2pi, qc, c, q, e, a)
        on_match(n, m, cx, qc, c, q, e, a)


def diffusion(qc, c, q, e):
    for i in range(0, len(q)):
        qc.h(q[i])
        qc.x(q[i])

    # controlled Z
    util.controlled_Z(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(0, len(q) - 1)], e, [q[len(q) - 1]])

    for i in range(0, len(q)):
        qc.x(q[i])
        qc.h(q[i])


def grover_iterate(qbits, good, qc, c, t, e, a):
    # oracle
    oracle(qbits, good, qc, c, t, e, a)

    # diffusion
    diffusion(qc, c, t, e)


def build_circuit(t_qbits, c_qbits, good):
    t = QuantumRegister(t_qbits, "target")
    c = QuantumRegister(c_qbits, "control")
    a = QuantumRegister(1, "ancilla")
    e = QuantumRegister(t_qbits, "extras")
    qc = QuantumCircuit(c, t, a, e)

    qc.x(a[0])
    qc.h(a[0])

    # hadamard on target qubits
    for i in range(t_qbits):
        qc.h(t[i])

    # hadamard on control qubits
    for i in range(c_qbits):
        qc.h(c[i])

    # # multiply the bad states by i
    # prepare_eigenvector(t_qbits, good, qc, t, e, a)

    for k in range(c_qbits):
        for _ in range(2**k):
            grover_iterate(t_qbits, good, qc, [c[k]], t, e, a)

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(c_qbits)])

    qc.h(a[0])

    return qc


if __name__ == "__main__":
    tgt_bits = 3
    ctrl_bits = 5

    qc = build_circuit(tgt_bits, ctrl_bits, [1, 3, 5, 7])
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    ordered_probs = sorted(probs.items(), key=lambda x: x[1], reverse=True)
    print("number of outcomes:", len(ordered_probs))
    print("probabilities = ", ordered_probs)

    counts = sorted(list(map(lambda item: (int(item[0][:ctrl_bits], 2), item[1]), ordered_probs)), key=lambda x: x[1], reverse=True)
    print("counts = ", counts)

    combined_counts = {}
    for k, v in counts:
        combined_counts[k] = np.round(combined_counts.get(k, 0) + v, 4)
    sorted_counts = sorted(combined_counts.items(), key=lambda x: x[1], reverse=True)
    print("combined_counts = ", sorted_counts)

    sines = {}
    for k, v in counts:
        key = 2**tgt_bits*np.round(np.cos(np.pi*k/2**ctrl_bits)**2, 4)
        sines[key] = sines.get(key, 0) + v
    sorted_sines = sorted(sines.items(), key=lambda x: x[1], reverse=True)
    print("sines = ", sorted_sines)

    print("Best Estimate = ", int(round(sorted_sines[0][0])))

    # [1, 2, 3]
    # sines =  [(3.22, 0.7577600000000001), (2.4696, 0.12337999999999993), (4.0, 0.038419999999999996), (1.7776, 0.0222)
    # Best Estimate =  3