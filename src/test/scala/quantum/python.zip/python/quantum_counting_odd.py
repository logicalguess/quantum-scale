import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j):
            crz(-np.pi / 2 ** (j - k), qc, q[j], q[k])


def oracle(qc, c, q, a):
    # qc.ccx(q[len(q) - 1], c[0], a[0]) # odds
    # qc.cx(c[0], a[0]) # all
    pass # none


def diffusion(qc, c, q, e):
    for i in range(0, len(q)):
        qc.h(q[i])
        qc.x(q[i])

    # controlled Z
    util.controlled_Z(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(0, len(q) - 1)], e, [q[len(q) - 1]])

    for i in range(0, len(q)):
        qc.x(q[i])
        qc.h(q[i])


def grover_iterate(qc, c, t, e, a):
    # oracle
    oracle(qc, c, t, a)

    # diffusion
    diffusion(qc, c, t, e)


def build_circuit(t_qbits = 2, c_qbits = 2):
    t = QuantumRegister(t_qbits, "target")
    c = QuantumRegister(c_qbits, "control")
    a = QuantumRegister(1, "ancilla")
    e = QuantumRegister(t_qbits - 1, "extras")
    qc = QuantumCircuit(c, t, a, e)

    qc.x(a[0])
    qc.h(a[0])

    # hadamard on target qubits
    for i in range(t_qbits):
        qc.h(t[i])

    # hadamard on control qubits
    for i in range(c_qbits):
        qc.h(c[i])

    # # multiply the bad states by i
    # prepare_eigenvector(t_qbits, good, qc, t, e, a)

    for k in range(c_qbits):
        for _ in range(2**k):
            grover_iterate(qc, [c[k]], t, e, a)

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(c_qbits)])

    qc.h(a[0])

    return qc


if __name__ == "__main__":
    tgt_bits = 2
    ctrl_bits = 2

    qc = build_circuit(tgt_bits, ctrl_bits)
    visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    ordered_probs = sorted(probs.items(), key=lambda x: x[1], reverse=True)
    print("number of outcomes:", len(ordered_probs))
    print("probabilities = ", ordered_probs)

    counts = sorted(list(map(lambda item: (int(item[0][:ctrl_bits], 2), item[1]), ordered_probs)), key=lambda x: x[1], reverse=True)
    print("counts = ", counts)

    combined_counts = {}
    for k, v in counts:
        combined_counts[k] = np.round(combined_counts.get(k, 0) + v, 4)
    sorted_counts = sorted(combined_counts.items(), key=lambda x: x[1], reverse=True)
    print("combined_counts = ", sorted_counts)

    sines = {}
    for k, v in counts:
        key = 2**tgt_bits*np.round(np.cos(np.pi*k/2**ctrl_bits)**2, 4)
        sines[key] = sines.get(key, 0) + v
    sorted_sines = sorted(sines.items(), key=lambda x: x[1], reverse=True)
    print("sines = ", sorted_sines)

    print("Best Estimate = ", int(round(sorted_sines[0][0])))

    # sines =  [(2.0, 1.0)]
    # Best Estimate =  2