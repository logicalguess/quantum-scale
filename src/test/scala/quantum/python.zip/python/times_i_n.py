import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def cry(theta, qc, q_control, q_target):
    qc.ry(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def cxzy(qc, q_control, q_target):
    qc.cx(q_control, q_target)
    qc.cz(q_control, q_target)
    qc.cy(q_control, q_target)


def controlled_XZY(qc, ctrl, anc, tgt):
    return util.controlled(qc, ctrl, anc, tgt, c_gate = lambda qc, ctrl, tgt: cxzy(qc, ctrl, tgt))


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def is_bit_set(m, k):
    return not (m & (1 << k))


def on_match_X(n, m, qc, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    util.controlled_X(qc, q, a, t)

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def on_no_match_XZY(n, m, qc, q, a, t):
    for i in range(0, n):
        if is_bit_set(m, i):
            qc.x(q[n - 1 - i])

    controlled_XZY(qc, q, a, t)

    for i in range(0, n):
        if is_bit_set(m, i):
            qc.x(q[n - 1 - i])


def build_circuit(n_qbits, m):
    t = QuantumRegister(n_qbits)
    a = QuantumRegister(1)
    b = QuantumRegister(n_qbits - 1)
    qc = QuantumCircuit(t, a, b)

    # hadamard on control qubits
    for i in range(n_qbits):
        qc.h(t[i])
        #qc.ry(np.pi/2, t[i])

    # for i in range(0,  n_qbits - 1):
    #     cry(-np.pi/2, qc, t[i], t[i + 1])


    # multiply by i
    # qc.x(a[0])
    # qc.z(a[0])
    # qc.y(a[0])

    # good states start with, bad states

    # good states get 1 appended at the end
    #qc.cx(t[0], a[0])
    on_match_X(n_qbits, m, qc, t, b, a)

    # multiply the bad states by i
    # qc.x(t[0])
    # cxzy(qc, t[0], a[0])
    # qc.x(t[0])
    #
    on_no_match_XZY(n_qbits, m, qc, t, b, a)

    # at this point the bad states have 1 appended,
    # the good states have 0 appended and are multiplied by i

    return qc


if __name__ == "__main__":
    n_ctrl_bits = 3
    qc = build_circuit(n_ctrl_bits, 1)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    print(probs)
