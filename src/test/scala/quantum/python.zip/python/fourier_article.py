# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import math
import numpy as np

import util

pi = np.pi
cos = np.cos
sin = np.sin

# k = first 3 bits reversed
# |k>: sqrt(1/8)*(cos(k*theta) + i*sin(k*theta))

def cry(theta, qc, q_control, q_target):
    qc.ry(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta/2, q_target)
    qc.cx(q_control, q_target)

def crz(theta, qc, q_control, q_target):
    qc.rz(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta/2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            qc.cu1(-np.pi/float(2**(j-k)), q[j], q[k])
            # crz(-np.pi/float(2**(j-k)), qc, q[j], q[k])


def rev(k):
    return int(format(k, 'b').zfill(3)[::-1], 2)

def build_circuit(n_qbits, theta):
    q = QuantumRegister(n_qbits)
    a = QuantumRegister(1)
    qc = QuantumCircuit(q, a)

    # qc.ry(theta, a[0])

    # qc.h(q[0])
    # qc.h(q[1])
    # qc.h(q[2])

    for i in range(n_qbits):
        qc.h(q[i])

    # cry(2*theta, qc, q[0], a[0])
    # cry(4*theta, qc, q[1], a[0])
    # cry(8*theta, qc, q[2], a[0])

    # prepare an eigenvector of ry(2*theta): i/sqrt(2)*|0> + 1/sqrt(2)*|1>
    # the corresponding eigenvalue is: cos(theta) + i*sin(theta)

    # version 1
    # qc.rx(np.pi/2, a[0])
    # qc.z(a[0])
    # qc.x(a[0])

    # version 2
    qc.x(a[0])
    qc.rx(-np.pi/2, a[0])

    for i in range(n_qbits):
        cry(2**(i+1)*theta, qc, q[i], a[0])

    iqft(qc, [q[i] for i in range(n_qbits)])

    qc.rx(np.pi/2, a[0])

    return qc, None, None


if __name__ == "__main__":

    n_tgt_bits = 3
    N = 2**n_tgt_bits

    t = 4.75
    theta = t*2*np.pi/N

    # f = 0.675
    # theta = f*2*np.pi
    # theta = 2*np.arcsin(np.sqrt(0.3))

    # state reversed
    param = cos(theta) + 1j*sin(theta)
    for k in range(N):
        print(format(k, 'b').zfill(3)[::-1], f"-> sqrt(1/8)*(cos({k}*theta) + i*sin({k}*theta)) -> ", 1j*np.round(math.sqrt(1/N)*param**k, 5))

    qc, _, _ = build_circuit(n_tgt_bits, theta)

    # from qiskit.tools.visualization import plot_circuit
    # plot_circuit(qc)

    state, hist = util.get_state_and_probs((qc, None, None), 'sim')
    print("Probabilities:", hist)
    from collections import OrderedDict
    from fractions import Fraction
    probs = OrderedDict((Fraction(int(key[0:n_tgt_bits], 2), N), np.round(value, 3)) for (key, value) in hist.items())
    # ordered = sorted(probs.items(), key=lambda x: x[1], reverse=True)
    util.plot_histogram(probs)

# visualization.plot_histogram(hist)

    # state_array = np.empty(N, dtype=np.complex_)
    # for i in range(N):
    #     key = format(i, 'b').zfill(3)
    #     state_array[i] = state.get(key[::-1] + '0')

    # print("state_array", state_array)

    param = cos(theta) + 1j*sin(theta)
    root = cos(2*pi/N) + 1j*sin(2*pi/N)

    state_array = np.empty(N, dtype=np.complex_)
    for k in range(N):
        state_array[k] = 1j*math.sqrt(1/N)*param**k

    for i in range(N):
        fourier = np.empty(N, dtype=np.complex_)
        for k in range(N):
            fourier[k] = math.sqrt(1/N)*root**(i*k)

        inner_product = np.vdot(fourier, state_array)
        print(i, " -> ", np.round(inner_product, 5))
        print(i, " -> ", np.round(abs(inner_product) ** 2, 5))
