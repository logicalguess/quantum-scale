import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def cry(theta, qc, q_control, q_target):
    qc.ry(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def controlled_ry(qc, times, ctrl, anc, tgt):
    return util.controlled(qc, ctrl, anc, tgt, c_gate = lambda qc, c, t: cry(1/2**n_ctrl_bits * 2*np.pi*times, qc, c, t))


def on_match_ry(n, m, qc, times, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    controlled_ry(qc, times, q, a, t)

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def on_match_bits_ry(qc, times, q1, q2, a, t):
    for i in range(0, times):
        util.controlled(qc, q1, a, t, c_gate = lambda qc, c, t: on_match_ry(3, 5, qc, 1, q2, a, t))


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            crz(-np.pi / float(2 ** (j - k)), qc, q[j], q[k])


def combine(n_bits, probs):

    def tick(y):
        return y

    combined = {}
    for b, c in probs.items():
        print(b, c)
        key = tick(int(b[0:n_bits], 2))
        combined[key] = combined.get(key, 0) + c
    return combined


def process_estimates(estimates):
    rounded = dict(
        map(lambda item: (item[0], np.round(item[1], 5)), estimates.items()))
    ordered = sorted(rounded.items(), key=lambda x: x[1], reverse=True)
    print("outcomes = ", ordered)


def build_circuit(n_qbits, m):
    t = QuantumRegister(n_qbits)
    a = QuantumRegister(1)
    b = QuantumRegister(n_qbits)
    c = QuantumRegister(n_qbits)
    qc = QuantumCircuit(c, t, a, b)

    # hadamard on control qubits
    for i in range(n_qbits):
        qc.h(t[i])

    # good states rotate the ancilla
    # on_match_ry(n_qbits, m, qc, 1, [t[i] for i in range(0, len(t))] + [c[0]], b, a)

    for i in range(n_qbits):
        qc.h(c[i])

    qc.rx(np.pi/2, a[0])
    qc.z(a[0])
    qc.x(a[0])

# controlled rotations
    for i in range(n_qbits):
        # on_match_ry(n_qbits, m, qc, 2**(i+1), [t[i] for i in range(0, len(t))] + [c[i]], b, a)
        # ! on_match_bits_ry(qc, 2**(i+1), [c[i]], [t[i] for i in range(n_qbits)], b, a)

        # cry(2 ** (i + 1) * 3/8 * 2*np.pi, qc, c[i], a[0])
        controlled_ry(qc, 2 ** (i + 1), [t[0], t[1], c[i]], b, a)

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(n_qbits)])

    return qc


if __name__ == "__main__":
    n_ctrl_bits = 3
    qc = build_circuit(n_ctrl_bits, 3)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    # print(probs)

    estimates = combine(n_ctrl_bits, probs)
    process_estimates(estimates)
