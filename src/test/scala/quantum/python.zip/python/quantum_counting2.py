import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j):
            crz(-np.pi / 2 ** (j - k), qc, q[j], q[k])


# multiply by i
def cxyz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cy(q_control, q_target)
    qc.cx(q_control, q_target)

# multiply by -i
def cyxz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    qc.cy(q_control, q_target)


# multiply by -1
def cxzx(qc, q_control, q_target):
    qc.cx(q_control, q_target)
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    #qc.cz(q_control, q_target)


def crx(theta, qc, q_control, q_target):
    qc.rx(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rx(-theta / 2, q_target)
    qc.cx(q_control, q_target)


# multiply by -1
def crz2pi(qc, q_control, q_target):
    crz(2*np.pi, qc, q_control, q_target)


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def on_match(n, m, gate, qc, c, q, e, a):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[i])

    util.controlled(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(len(q))], e, a, c_gate = lambda qc, ctrl, tgt: gate(qc, ctrl, tgt))

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[i])


def prepare_eigenvector(qbits, good, qc, t, e, a):
    # 1) multiply all states by i
    qc.z(a[0])
    qc.y(a[0])
    qc.x(a[0])
    # 2) multiply good states by -i
    for m in good:
        on_match(qbits, m, cyxz, qc, [], t, e, a)
        #on_match(qbits, m, crz2pi, qc, [], t, e, a)


def oracle(n, predicate, qc, c, q, e, a):
    for m in range(2**n):
        if predicate(m):
            # on_match(n, m, crz2pi, qc, c, q, e, a)
            on_match(n, m, cxzx, qc, c, q, e, a) # if ancilla is guaranteed to stay in 0 no need to start with z


def diffusion(qc, c, q, e):
    for i in range(0, len(q)):
        qc.h(q[i])
        qc.x(q[i])

    # controlled Z
    util.controlled_Z(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(0, len(q) - 1)], e, [q[len(q) - 1]])

    for i in range(0, len(q)):
        qc.x(q[i])
        qc.h(q[i])


def grover_iterate(qbits, predicate, qc, c, t, e, a):
    # oracle
    oracle(qbits, predicate, qc, c, t, e, a)

    # diffusion
    diffusion(qc, c, t, e)


def build_circuit(t_qbits, c_qbits, predicate):
    t = QuantumRegister(t_qbits, "target")
    c = QuantumRegister(c_qbits, "control")
    a = QuantumRegister(1, "ancilla")
    e = QuantumRegister(t_qbits, "extras")
    qc = QuantumCircuit(c, t, a, e)

    # hadamard on target qubits
    for i in range(t_qbits):
        qc.h(t[i])

    # hadamard on control qubits
    for i in range(c_qbits):
        qc.h(c[i])

    # # multiply the bad states by i
    # prepare_eigenvector(t_qbits, predicate, qc, t, e, a)

    for i in range(c_qbits):
        for _ in range(2**i):
            grover_iterate(t_qbits, predicate, qc, [c[i]], t, e, a)

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(c_qbits)])

    return qc


if __name__ == "__main__":
    tgt_bits = 3
    ctrl_bits = 5

    qc = build_circuit(tgt_bits, ctrl_bits, lambda k: k & k >> 1 == 0)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    ordered_probs = sorted(probs.items(), key=lambda x: x[1], reverse=True)
    print("number of outcomes:", len(ordered_probs))
    print("probabilities = ", ordered_probs)

    counts = sorted(list(map(lambda item: (int(item[0][:ctrl_bits], 2), item[1]), ordered_probs)), key=lambda x: x[1], reverse=True)
    print("counts = ", counts)

    combined_counts = {}
    for k, v in counts:
        combined_counts[k] = np.round(combined_counts.get(k, 0) + v, 4)
    sorted_counts = sorted(combined_counts.items(), key=lambda x: x[1], reverse=True)
    print("combined_counts = ", sorted_counts)

    sines = {}
    for k, v in counts:
        key = 2**tgt_bits*np.round(np.cos(np.pi*k/2**ctrl_bits)**2, 4)
        sines[key] = sines.get(key, 0) + v
    sorted_sines = sorted(sines.items(), key=lambda x: x[1], reverse=True)
    print("sines = ", sorted_sines)

    print("Best Estimate = ", int(round(sorted_sines[0][0])))

    # tgt_bits = 2
    # ctrl_bits = 3
    # sines =  [(3.4144, 0.7064600000000002), (2.0, 0.18747999999999995), (4.0, 0.04688999999999999), (0.5856, 0.043559999999999995), (0.0, 0.01564)]
    # Best Estimate =  3

    # tgt_bits = 3
    # ctrl_bits = 5
    # sines =  [(4.78, 0.7577600000000001), (5.5304, 0.12337999999999993), (4.0, 0.038419999999999996), (6.2224, 0.0222)
    # Best Estimate =  5

    # tgt_bits = 4
    # ctrl_bits = 4
    # sines =  [(8.0, 1.0)]
    # Best Estimate =  8

    # tgt_bits = 5
    # ctrl_bits = 5
    # sines =  [(12.88, 0.9949600000000014), (16.0, 0.0018000000000000021), (9.8784, 0.001280000000000002), (7.1104, 0.00038000000000000035)
    # Best Estimate =  13

    # tgt_bits = 5
    # ctrl_bits = 6
    #
    # sines =  [(12.88, 0.9796999999999998), (14.432, 0.007319999999999992), (11.3568, 0.005380000000000007), (16.0, 0.0018000000000000021),
    # Best Estimate =  13


    # tgt_bits = 6
    # ctrl_bits = 7
    #
    # sines =  [(21.2224, 0.9297200000000043), (19.7568, 0.028480000000000016), (22.7136, 0.015719999999999984), (18.3168, 0.006380000000000011), (24.224, 0.004240000000000005), (16.9152, 0.0029800000000000048), (25.76, 0.0021200000000000025), (27.3024, 0.0017000000000000032), (14.2208, 0.0012800000000000027), (15.5456, 0.0012800000000000027), (32.0, 0.00042000000000000045), (28.864, 0.00042000000000000045), (30.432, 0.00042000000000000045), (12.9408, 0.00042000000000000045)]
    # Best Estimate =  21

    # 7 hrs
    # tgt_bits = 7
    # ctrl_bits = 8
    # sines =  [(33.8304, 0.9521599999999969), (35.2256, 0.01892000000000006), (32.4608, 0.011080000000000036), (36.6336, 0.003920000000000007), (31.0912, 0.003240000000000007), (39.5136, 0.0006800000000000011), (28.4416, 0.0006800000000000011), (38.0672, 0.0006800000000000011), (29.76, 0.0006800000000000011)]
    # Best Estimate =  34

    #########################

    # tgt_bits = 6
    # ctrl_bits = 4
    # sines =  [(19.7568, 0.9637400000000027), (32.0, 0.014399999999999934), (9.3696, 0.009820000000000027), (44.2432, 0.0033800000000000032)
    # Best Estimate =  20

    # tgt_bits = 6
    # ctrl_bits = 5
    # sines =  [(19.7568, 0.8597599999999994), (25.76, 0.06286000000000025), (14.2208, 0.02722), (32.0, 0.012740000000000046), (9.3696, 0.008939999999999993)
    # Best Estimate =  20

    # tgt_bits = 6
    # ctrl_bits = 6
    # sines =  [(19.7568, 0.5300800000000011), (22.7136, 0.2908400000000004), (16.9152, 0.04751999999999985), (25.76, 0.039160000000000084)
    # Best Estimate =  20

    # tgt_bits = 7
    # ctrl_bits = 4
    # sines =  [(39.5136, 0.8239599999999945), (18.7392, 0.08796000000000015), (64.0, 0.03391999999999998), (4.8768, 0.02080000000000002)
    # Best Estimate =  40

