# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import math
import numpy as np

import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import util


def build_circuit(phi):
    q = QuantumRegister(2)
    qc = QuantumCircuit(q)

    # qc.ry(phi, q[0])
    # qc.h(q[0])
    # qc.ry(phi, q[0])

    # qc.ry(2*phi, q[0])
    # qc.cx(q[0], q[1])
    # qc.h(q[0])
    # qc.cx(q[1], q[0])
    # qc.cx(q[0], q[1])
    # qc.ry(2*phi, q[1])

    qc.ry(phi, q[0])

    # these 2 lines create the typical Bell state
    ##################
    qc.h(q[0])
    qc.cx(q[0], q[1])
    ##################

    qc.cx(q[1], q[0])
    qc.ry(phi, q[1])
    qc.cx(q[1], q[0])


    return qc, None, None


if __name__ == "__main__":

    phi = 0.735*np.pi

    qc, _, _ = build_circuit(phi)

    from qiskit.tools.visualization import plot_circuit
    plot_circuit(qc)

    hist = util.get_probs((qc, None, None), 'sim')
    print("Probabilities:", hist)

    visualization.plot_histogram(hist)
