import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def controlled_ry(qc, theta, ctrl, anc, tgt):
    return util.controlled(qc, ctrl, anc, tgt, c_gate = lambda qc, c, t: cry(theta, qc, c, t))


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def on_match_X(n, m, qc, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    util.controlled_X(qc, q, a, t)

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def combine(n_bits, probs):

    def tick(y):
        return y

    combined = {}
    for b, c in probs.items():
        print(b, c)
        key = tick(int(b[0:1], 2))
        combined[key] = combined.get(key, 0) + c
        input = int(b[1:n_bits+1], 2)
        print("indicator: ", input, " -> ", key)
    return combined


def process_estimates(estimates):
    rounded = dict(
        map(lambda item: (item[0], np.round(item[1], 5)), estimates.items()))
    ordered = sorted(rounded.items(), key=lambda x: x[1], reverse=True)
    print("outcomes = ", ordered)


def build_circuit(n_qbits, indicator):
    o = QuantumRegister(1)
    e = QuantumRegister(n_qbits)
    t = QuantumRegister(n_qbits)
    qc = QuantumCircuit(o, t, e)

    for i in range(n_qbits):
        qc.h(t[i])


    for k in range(2**n_qbits):
        if indicator[k] == 1:
            on_match_X(n_qbits, k, qc, t, e, o[0])

    return qc


if __name__ == "__main__":
    indicator =	{
        0: 0,
        1: 0,
        2: 1,
        3: 1,
        4: 1,
        5: 0,
        6: 0,
        7: 0
    }

    n_bits = 3

    qc = build_circuit(n_bits, indicator)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    # print(probs)

    estimates = combine(n_bits, probs)
    process_estimates(estimates)

    # outcomes =  [(0, 0.625), (1, 0.375)]