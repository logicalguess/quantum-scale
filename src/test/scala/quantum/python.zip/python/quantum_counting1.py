import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j):
            crz(-np.pi / 2 ** (j - k), qc, q[j], q[k])


# multiply by i
def cxyz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cy(q_control, q_target)
    qc.cx(q_control, q_target)

# multiply by -i
def cyxz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    qc.cy(q_control, q_target)


# multiply by -1
def cxzx(qc, q_control, q_target):
    qc.cx(q_control, q_target)
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    #qc.cz(q_control, q_target)


def crx(theta, qc, q_control, q_target):
    qc.rx(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rx(-theta / 2, q_target)
    qc.cx(q_control, q_target)


# multiply by -1
def crz2pi(qc, q_control, q_target):
    crz(2*np.pi, qc, q_control, q_target)


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def on_match(n, m, gate, qc, c, q, e, a):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[i])

    util.controlled(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(len(q))], e, a, c_gate = lambda qc, ctrl, tgt: gate(qc, ctrl, tgt))

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[i])


def prepare_eigenvector(qbits, good, qc, t, e, a):
    # 1) multiply all states by i
    qc.z(a[0])
    qc.y(a[0])
    qc.x(a[0])
    # 2) multiply good states by -i
    for m in good:
        on_match(qbits, m, cyxz, qc, [], t, e, a)
        #on_match(qbits, m, crz2pi, qc, [], t, e, a)


def oracle(qc, c, e, a):
    util.controlled(qc, [c[i] for i in range(len(c))], e, a, c_gate = cxzx)


def diffusion(qc, c, q, e):
    for i in range(0, len(q)):
        qc.h(q[i])
        qc.x(q[i])

    # controlled Z
    util.controlled_Z(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(0, len(q) - 1)], e, [q[len(q) - 1]])

    for i in range(0, len(q)):
        qc.x(q[i])
        qc.h(q[i])


def grover_iterate(qc, c, t, e, a):
    # oracle
    oracle(qc, c, e, a)

    # diffusion
    diffusion(qc, c, t, e)


def cry(theta, qc, q_control, q_target):
    qc.ry(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta/2, q_target)
    qc.cx(q_control, q_target)


def build_circuit(t_qbits, c_qbits):
    t = QuantumRegister(t_qbits, "target")
    c = QuantumRegister(c_qbits, "control")
    a = QuantumRegister(1, "ancilla")
    e = QuantumRegister(t_qbits, "extras")
    qc = QuantumCircuit(c, t, a, e)

    # hadamard on target qubits
    for i in range(t_qbits):
        qc.h(t[i])

    # Fibonacci constraints
    for i in range(0,  t_qbits - 1):
        cry(-np.pi/2, qc, t[i], t[i + 1])


    # hadamard on control qubits
    for i in range(c_qbits):
        qc.h(c[i])

    # # multiply the bad states by i
    # prepare_eigenvector(t_qbits, good, qc, t, e, a)

    for k in range(c_qbits):
        for _ in range(2**k):
            grover_iterate(qc, [c[k]], t, e, a)

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(c_qbits)])

    return qc


if __name__ == "__main__":
    tgt_bits = 8
    ctrl_bits = 2

    qc = build_circuit(tgt_bits, ctrl_bits)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    ordered_probs = sorted(probs.items(), key=lambda x: x[1], reverse=True)
    print("number of outcomes:", len(ordered_probs))
    print("probabilities = ", ordered_probs)

    counts = sorted(list(map(lambda item: (int(item[0][:ctrl_bits], 2), item[1]), ordered_probs)), key=lambda x: x[1], reverse=True)
    print("counts = ", counts)

    combined_counts = {}
    for k, v in counts:
        combined_counts[k] = np.round(combined_counts.get(k, 0) + v, 4)
    sorted_counts = sorted(combined_counts.items(), key=lambda x: x[1], reverse=True)
    print("combined_counts = ", sorted_counts)

    sines = {}
    for k, v in counts:
        key = 2**tgt_bits*np.round(np.cos(np.pi*k/2**ctrl_bits)**2, 4)
        sines[key] = sines.get(key, 0) + v
    sorted_sines = sorted(sines.items(), key=lambda x: x[0], reverse=False)
    print("sines = ", sorted_sines)

    print("Estimate = ", sorted_sines[1][0]*sorted_sines[1][1])

    # tgt_bits = 3
    # ctrl_bits = 2
    # sines =  [(0.0, 0.39110999999999996), (8.0, 0.6089599999999998)]
    # Estimate =  4.871679999999999

    # tgt_bits = 4
    # ctrl_bits = 2
    # sines =  [(0.0, 0.52129), (16.0, 0.47888000000000014)]
    # Estimate =  7.662080000000002

    # tgt_bits = 5
    # ctrl_bits = 2
    # sines =  [(0.0, 0.6131999999999994), (32.0, 0.38655999999999985)]
    # Estimate =  12.369919999999995

    # tgt_bits = 6
    # ctrl_bits = 2
    # sines =  [(0.0, 0.6912400000000016), (64.0, 0.3084799999999997)]
    # Estimate =  19.74271999999998

    # tgt_bits = 7
    # ctrl_bits = 2
    # sines =  [(0.0, 0.7527400000000048), (128.0, 0.2483199999999997)]
    # Estimate =  31.784959999999963

    # tgt_bits = 8
    # ctrl_bits = 2
    # sines =  [(0.0, 0.800900000000009), (256.0, 0.19711999999999988)]
    # Estimate =  50.46271999999997