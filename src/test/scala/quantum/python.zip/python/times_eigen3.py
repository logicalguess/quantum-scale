import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            crz(-np.pi / float(2 ** (j - k)), qc, q[j], q[k])


# multiply by i
def cxyz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cy(q_control, q_target)
    qc.cx(q_control, q_target)

# multiply by -i
def cyxz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    qc.cy(q_control, q_target)


# multiply by -1
def czxzx(qc, q_control, q_target):
    qc.cx(q_control, q_target)
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    qc.cz(q_control, q_target)

# multiply by -1
def crx2pi(qc, q_control, q_target):
    qc.crx(2*np.pi, q_control, q_target)


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def on_match(n, m, gate, qc, c, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    util.controlled(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(len(q))], a, t, c_gate = lambda qc, ctrl, tgt: gate(qc, ctrl, tgt))

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def on_match_ones(gate, qc, c, q, a, t):
    util.controlled(qc, [c[i] for i in range(len(c))] + [q[0], q[1], q[2]], a, t, c_gate = lambda qc, ctrl, tgt: gate(qc, ctrl, tgt))


def prepare_eigenvector(n_qbits, good, qc, t, b, a):
    # 1) multiply all states by i
    qc.z(a[0])
    qc.y(a[0])
    qc.x(a[0])
    # 2) multiply good states by -i
    for m in good:
        #on_match(n_qbits, m, cyxz, qc, [], t, b, a)
        on_match(n_qbits, m, crx2pi, qc, [], t, b, a)


def oracle(n, good, qc, c, q, a, t):
    for m in good:
        on_match(n, m, czxzx, qc, c, q, a, t)


def diffusion(qc, c, q, a):
    for i in range(0, len(q)):
        qc.h(q[i])
        qc.x(q[i])

    # controlled Z
    util.controlled_Z(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(0, len(q) - 1)], a, [q[len(q) - 1]])

    for i in range(0, len(q)):
        qc.x(q[i])
        qc.h(q[i])


def grover_iterate(n_qbits, good, qc, c, t, b, a):
    # oracle
    oracle(n_qbits, good, qc, c, t, b, a)

    # diffusion
    diffusion(qc, c, t, b)


def build_circuit(n_t_qbits, n_c_qbits, good):
    t = QuantumRegister(n_t_qbits)
    c = QuantumRegister(n_c_qbits)
    a = QuantumRegister(1)
    b = QuantumRegister(n_t_qbits)
    qc = QuantumCircuit(c, t, a, b)

    # hadamard on target qubits
    for i in range(n_t_qbits):
        qc.h(t[i])
        #qc.ry(np.pi/2, t[i])

    # hadamard on conytol qubits
    for i in range(n_c_qbits):
        qc.h(c[i])

    # # multiply the bad states by i
    # prepare_eigenvector(n_t_qbits, good, qc, t, b, a)


    # # just grover search
    # for j in range(0, int(math.sqrt(2**n_qbits))):
    #     grover_iterate(n_qbits, m, qc, [], [t[i] for i in range(n_qbits)], b, a)

    for k in range(n_c_qbits):
        for _ in range(2**k):
            grover_iterate(n_t_qbits, good, qc, [c[k]], t, b, a)

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(n_c_qbits)])

    return qc


if __name__ == "__main__":
    n_tgt_bits = 3
    n_ctrl_bits = 5

    qc = build_circuit(n_tgt_bits, n_ctrl_bits, [1])
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    ordered = sorted(probs.items(), key=lambda x: x[1], reverse=True)
    print("number of outcomes:", len(ordered))
    print(ordered)

    counts = sorted(list(map(lambda item: (int(item[0][:n_ctrl_bits], 2), item[1]), ordered)), key=lambda x: x[1], reverse=True)
    print("counts = ", counts)

    combined_counts = {}
    for k, v in counts:
        combined_counts[k] = np.round(combined_counts.get(k, 0) + v, 4)
    sorted_counts = sorted(combined_counts.items(), key=lambda x: x[1], reverse=True)
    print("combined_counts = ", sorted_counts)

    sines = {}
    for k, v in sorted_counts:
        key = 2**n_tgt_bits*np.round(np.sin(np.pi*k/2**n_ctrl_bits)**2, 4)
        sines[key] = sines.get(key, 0) + v
    sorted_sines = sorted(sines.items(), key=lambda x: x[1], reverse=True)
    print("sines = ", sorted_sines)

    print("Best Estimate = ", 8 - int(round(sorted_sines[0][0])))

