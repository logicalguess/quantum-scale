import numpy as np

pi = np.pi


if __name__ == "__main__":
    n_ctrl_bits = 3
    N = 2**n_ctrl_bits

    t = 5.7

    print("t = ", t)

    for k in range(N):
        d = t - k
        if d != 0:
            pr = np.sin(np.pi*d)**2/np.sin(np.pi/N*d)**2/N**2
            print(k, " -> ", np.round(pr, 5))

    for i in range(N):
        fourier = np.empty(N, dtype=np.complex_)
        root = np.cos(i*2*pi/N) + 1j*np.sin(i*2*pi/N)
        for k in range(N):
            fourier[k] = root**k

        f = np.empty(N, dtype=np.complex_)
        param = np.cos(t*2*pi/N) + 1j*np.sin(t*2*pi/N)
        for k in range(N):
            f[k] = param**k

        print(i, " -> ", np.round(abs(np.vdot(f, fourier)/N)**2, 5))
