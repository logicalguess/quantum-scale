import numpy as np

pi = np.pi
cos = np.cos
sin = np.sin

if __name__ == "__main__":
    N = 8

    t = 5.7

    print("t = ", t)

    for k in range(N):
        if t - k != 0:
            theta = 2*pi/N * (t - k)
            pr = sin(N*theta/2)**2/sin(theta/2)**2/N**2
            print(k, " -> ", np.round(pr, 5))

        # Fejer over N
        f = 0.0
        for j in range(N):
            theta = 2 * pi / N * (t - k)
            f = f + 2/N**2 * (N - j) * cos(j*theta)
        f = f - 1.0/N  # index 0 was doubly counted

        print(k, " -> ", np.round(f, 5))

