import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            crz(-np.pi / float(2 ** (j - k)), qc, q[j], q[k])


# multiply by i
def cxyz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cy(q_control, q_target)
    qc.cx(q_control, q_target)

# multiply by -i
def cyxz(qc, q_control, q_target):
    qc.cz(q_control, q_target)
    qc.cx(q_control, q_target)
    qc.cy(q_control, q_target)

def is_bit_not_set(m, k):
    return not (m & (1 << k))


def on_match(n, m, gate, qc, c, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    util.controlled(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(len(q))], a, t, c_gate = lambda qc, ctrl, tgt: gate(qc, ctrl, tgt))

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    #util.controlled(qc, [c[i] for i in range(len(c))] + [q[0]], a, t, c_gate = lambda qc, ctrl, tgt: gate(qc, ctrl, tgt))


def prepare_eigenvector(n_qbits, m, qc, t, b, a):
    # 1) multiply all states by i
    qc.z(a[0])
    qc.y(a[0])
    qc.x(a[0])
    # 2) multiply good states by -i
    on_match(n_qbits, m, cyxz, qc, [], t, b, a)


def oracle(n, m, qc, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    util.controlled_X(qc, [q[0], q[1]], a, t)

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def diffusion(qc, c, q, a):
    for i in range(0, len(q)):
        qc.h(q[i])
        qc.x(q[i])

    # controlled Z
    util.controlled_Z(qc, [c[i] for i in range(len(c))] + [q[i] for i in range(0, len(q) - 1)], a, [q[len(q) - 1]])

    for i in range(0, len(q)):
        qc.x(q[i])
        qc.h(q[i])


def grover_iterate(n_qbits, m, qc, c, t, b, a):
    # controlled oracle
    qc.cz(c, a)
    oracle(n_qbits, m, qc, t, b, a)
    qc.cz(c, a)

    # diffusion
    diffusion(qc, [c], t, b)


def build_circuit(n_qbits, m):
    t = QuantumRegister(n_qbits)
    c = QuantumRegister(n_qbits)
    a = QuantumRegister(1) # main ancilla to work on
    b = QuantumRegister(n_qbits - 1) # extra ancillas for toffolis
    qc = QuantumCircuit(c, t, a, b)

    # hadamard on target qubits
    for i in range(n_qbits):
        qc.h(t[i])
        #qc.ry(np.pi/2, t[i])

    # hadamard on conytol qubits
    for i in range(n_qbits):
        qc.h(c[i])

    qc.h(a[0])

    for k in range(n_qbits):
        for _ in range(2**k):
            grover_iterate(n_qbits, m, qc, c[k], t, b, a)


    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(n_qbits)])

    return qc


if __name__ == "__main__":
    n_ctrl_bits = 3
    qc = build_circuit(n_ctrl_bits, 3)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    ordered = sorted(probs.items(), key=lambda x: x[1], reverse=True)
    print("number of outcomes:", len(ordered))
    print(ordered)

    #sines = list(map(lambda item: (np.round(np.power(np.sin(np.pi*int(item[0][:3]), 2), 2), 4), item[1]), ordered))
    counts = list(map(lambda item: (int(item[0][:3], 2), item[1]), ordered))
    print("counts = ", counts)

    combined_counts = {}
    for k, v in counts:
        combined_counts[k] = combined_counts.get(k, 0) + v
    print("combined_counts = ", combined_counts)


    #print(np.round(np.power(np.sin(np.pi*5/4), 2), 4))

