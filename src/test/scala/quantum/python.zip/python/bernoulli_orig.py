import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, ClassicalRegister, QuantumRegister, execute
from qiskit.tools import visualization


def cry(theta, qc, q_control, q_target):
    qc.ry(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta/2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        print("h", j)
        qc.h(q[j])
        for k in range(j)[::-1]:
            print("cu1", j, k)
            theta_jk = -np.pi/float(2**(j-k))
            qc.cu1(theta_jk, q[j], q[k])


def circuit(theta):

    q = QuantumRegister(4)
    c = ClassicalRegister(4)

    qc = QuantumCircuit(q, c)

    # A
    qc.ry(theta, q[3])

    # H
    qc.h(q[0])
    qc.h(q[1])
    qc.h(q[2])

    # Q
    cry(2*theta, qc, q[0], q[3])
    cry(4*theta, qc, q[1], q[3])
    cry(8*theta, qc, q[2], q[3])

    # IQFT
    iqft(qc, [q[0], q[1], q[2]])

    # qc.h(q[2])
    # qc.cu1(-np.pi/float(2**(2-1)), q[2], q[1])
    # qc.cu1(-np.pi/float(2**(2-0)), q[2], q[0])
    #
    # qc.h(q[1])
    # qc.cu1(-np.pi/float(2**(1-0)), q[1], q[0])
    #
    # qc.h(q[0])



    # measure
    #qc.barrier(q)

    # qc.measure(q[3], c[0])
    #
    # qc.measure(q[0], c[3])
    # qc.measure(q[1], c[2])
    # qc.measure(q[2], c[1])

    return qc


def run_circuit(circuit):
    # Execute circuit
    job = execute([circuit], backend='local_qasm_simulator', shots=1000)
    result = job.result()

    return result.get_counts()


def counts_to_estimate(m, counts):
    M = 2**m
    y_to_p = lambda y: np.power(np.sin(np.pi*y/M), 2)

    shots = sum(counts.values())

    results = {}
    ints = {}
    freqs = {}

    for b, c in counts.items():
        freqs[b] = freqs.get(b, 0) + c/shots

        y = int(b[0:(m)], 2)
        ints[y] = ints.get(y, 0) + c/shots

        # print("b", b[1:(m+1)])
        # print("y", y)

        p_ = y_to_p(y)

        key = float('%.4f' % p_)
        results[key] = results.get(key, 0) + c/shots

    print(freqs)
    print(ints)
    return results


if __name__ == "__main__":
    p = 0.3
    theta_p = 2*np.arcsin(np.sqrt(p))

    qc = circuit(theta_p)
    # visualization.plot_circuit(qc)

    import util
    cs = util.get_probs((qc, None, None), 'sim')

    #cs = run_circuit(qc)
    visualization.plot_histogram(cs)

    results = counts_to_estimate(3, cs)
    print(results)