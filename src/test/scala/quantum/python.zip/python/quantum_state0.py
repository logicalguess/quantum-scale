import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def cry(theta, qc, q_control, q_target):
    qc.ry(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def controlled_ry(qc, theta, ctrl, anc, tgt):
    return util.controlled(qc, ctrl, anc, tgt, c_gate = lambda qc, c, t: cry(theta, qc, c, t))


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def on_match_X(n, m, qc, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    util.controlled_X(qc, q, a, t)

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            crz(-np.pi / float(2 ** (j - k)), qc, q[j], q[k])


def combine(n_bits, probs):

    def tick(y):
        return y

    combined = {}
    for b, c in probs.items():
        print(b, c)
        key = tick(int(b[0:n_bits], 2))
        combined[key] = combined.get(key, 0) + c
        input = int(b[n_bits:n_bits + n_bits], 2)
        print("indicator: ", input, " -> ", key)
    return combined


def process_estimates(estimates):
    rounded = dict(
        map(lambda item: (item[0], np.round(item[1], 5)), estimates.items()))
    ordered = sorted(rounded.items(), key=lambda x: x[1], reverse=True)
    print("outcomes = ", ordered)


def build_circuit(n_ctrl_bits, n_qbits, indicator):
    a = QuantumRegister(1)
    o = QuantumRegister(1)
    e = QuantumRegister(n_qbits)
    c = QuantumRegister(n_ctrl_bits)
    t = QuantumRegister(n_qbits)
    qc = QuantumCircuit(c, t, o, a, e)

    for i in range(n_ctrl_bits):
        qc.h(c[i])

    for i in range(n_qbits):
        qc.h(t[i])

    qc.rx(np.pi/2, a[0])
    qc.z(a[0])
    qc.x(a[0])

    for k in range(2**n_qbits):
        if indicator[k] == 1:
            on_match_X(n_qbits, k, qc, t, e, o[0])

    # rotations
    for i in range(n_ctrl_bits):
        # for k in range(2**n_qbits):
            # cry(1 / 2 ** n_qbits * 2 * np.pi * 2 ** (i+1) * indicator[k], qc, c[i], a[0])
            # controlled_ry(qc, (1/2 ** n_qbits) * 2 * np.pi * 2 ** (i+1)* indicator[k], [c[i]], e, a[0])

        controlled_ry(qc, (1/2 ** n_qbits) * 2 * np.pi * 2 ** (i+1), [o[0], c[i]], e, a[0])

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(n_ctrl_bits)])

    qc.rx(-np.pi/2, a[0])

    return qc


if __name__ == "__main__":
    indicator =	{
        0: 0,
        1: 0,
        2: 1,
        3: 1,
        4: 1,
        5: 0,
        6: 0,
        7: 0
    }

    n_ctrl_bits = 3
    n_tgt_bits = 3

    qc = build_circuit(n_ctrl_bits, n_tgt_bits, indicator)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    # print(probs)

    estimates = combine(n_ctrl_bits, probs)
    process_estimates(estimates)

    # outcomes =  [(0, 0.625), (1, 0.375)]