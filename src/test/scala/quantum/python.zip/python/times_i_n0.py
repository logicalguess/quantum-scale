import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def cry(theta, qc, q_control, q_target):
    qc.ry(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def controlled_ry(qc, times, ctrl, anc, tgt):
    return util.controlled(qc, ctrl, anc, tgt, c_gate = lambda qc, c, t: cry(1/2**n_ctrl_bits * 2*np.pi*times, qc, c, t))


def on_match_ry(n, m, qc, times, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    controlled_ry(qc, times, q, a, t)

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def combine(n_bits, probs):

    def tick(y):
        return y

    combined = {}
    for b, c in probs.items():
        print(b, c)
        key = tick(int(b[0:n_bits], 2))
        combined[key] = combined.get(key, 0) + c
    return combined


def process_estimates(estimates):
    rounded = dict(
        map(lambda item: (item[0], np.round(item[1], 5)), estimates.items()))
    ordered = sorted(rounded.items(), key=lambda x: x[1], reverse=True)
    print("outcomes = ", ordered)

    print("count", int(8*rounded.get(1)/(np.sin(np.pi/8) ** 2)))


def build_circuit(n_qbits, m):
    t = QuantumRegister(n_qbits)
    a = QuantumRegister(1)
    b = QuantumRegister(n_qbits)
    qc = QuantumCircuit(a, t, b)

    # hadamard on control qubits
    for i in range(n_qbits):
        qc.h(t[i])

    # good states rotate the ancilla
    on_match_ry(n_qbits, m, qc, 1, t, b, a)
    # controlled_ry(qc, 1, [t[0], t[1]], b, a)

    return qc


if __name__ == "__main__":
    n_ctrl_bits = 3
    qc = build_circuit(n_ctrl_bits, 5)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    # print(probs)

    estimates = combine(1, probs)
    process_estimates(estimates)
