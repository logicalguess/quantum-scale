import numpy as np

pi = np.pi


if __name__ == "__main__":
    N = 128

    t = 0.3

    print("t = ", t)

    ts = 1/N  # sampling period

    s = 0.0
    sq = 0.0

    for k in range(N):
        d = t - k*ts
        coeff = np.sin(pi*d/ts)/np.sin(pi*d)/N
        # print(k, " -> ", np.round(coeff, 5))

        s = s + coeff
        sq = sq + coeff**2

    print("sum = ", np.round(s, 5))
    print("sum of squares = ", np.round(sq, 5))

    # N = 1024
    #
    # sum =  0.99929
    # sum of squares =  1.0

    # N = 256
    #
    # sum =  1.00283
    # sum of squares =  1.0
