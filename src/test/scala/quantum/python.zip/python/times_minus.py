import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


# multiply by -1
def cxyxy(qc, q_control, q_target):
    qc.cy(q_control, q_target)
    qc.cx(q_control, q_target)
    qc.cy(q_control, q_target)
    qc.cx(q_control, q_target)


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def on_match_X(n, m, qc, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    util.controlled_X(qc, q, a, t)

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def on_match(n, m, gate, qc, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])

    util.controlled(qc, q, a, t, c_gate = lambda qc, ctrl, tgt: gate(qc, ctrl, tgt))

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[n - 1 - i])


def build_circuit(n_qbits, m):
    t = QuantumRegister(n_qbits)
    a = QuantumRegister(1)
    b = QuantumRegister(n_qbits - 1)
    qc = QuantumCircuit(t, a, b)

    # hadamard on control qubits
    for i in range(n_qbits):
        qc.h(t[i])
        #qc.ry(np.pi/2, t[i])

    # good states get multiplied by -1
    on_match(n_qbits, m, cxyxy, qc, t, b, a)

    # # alternative way
    # # set last bit to -
    # qc.x(a[0])
    # qc.h(a[0])
    # # X on - changes the sign of both amplitudes by swappimg them
    # on_match_X(n_qbits, m, qc, t, b, a)

    return qc


if __name__ == "__main__":
    n_ctrl_bits = 3
    qc = build_circuit(n_ctrl_bits, 7)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    # visualization.plot_histogram(probs)

    print(probs)
