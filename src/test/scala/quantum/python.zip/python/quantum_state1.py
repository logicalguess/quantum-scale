import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def cry(theta, qc, q_control, q_target):
    qc.ry(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            crz(-np.pi / float(2 ** (j - k)), qc, q[j], q[k])


def combine(n_bits, probs):

    def tick(y):
        return y

    combined = {}
    for b, c in probs.items():
        print(b, c)
        key = tick(int(b[0:n_bits], 2))
        combined[key] = combined.get(key, 0) + c
    return combined


def process_estimates(estimates):
    rounded = dict(
        map(lambda item: (item[0], np.round(item[1], 5)), estimates.items()))
    ordered = sorted(rounded.items(), key=lambda x: x[1], reverse=True)
    print("outcomes = ", ordered)

    interpol = map(lambda item: np.round(item[0]*item[1], 5), estimates.items())
    print("interpol", sum(interpol))


def build_circuit(n_qbits, param):
    a = QuantumRegister(1)
    c = QuantumRegister(n_qbits)
    qc = QuantumCircuit(c, a)

    for i in range(n_qbits):
        qc.h(c[i])

    qc.rx(np.pi/2, a[0])
    qc.z(a[0])
    qc.x(a[0])

    # rotations
    for i in range(n_qbits):
        cry(1 / 2 ** n_qbits * 2 * np.pi * 2 ** (i+1) * param, qc, c[i], a[0])

    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(n_qbits)])

    qc.rx(-np.pi/2, a[0])

    return qc


if __name__ == "__main__":
    p = 5.7

    n_ctrl_bits = 3
    qc = build_circuit(n_ctrl_bits, p)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    probs1 = dict(('%d' % int(key[:-1], 2) + " = " + key[:-1], np.round(value, 3)) for (key, value) in probs.items())
    util.plot_histogram(probs1)

    # visualization.plot_histogram(probs1)

    # print(probs)

    estimates = combine(n_ctrl_bits, probs)
    process_estimates(estimates)

    N = 2**n_ctrl_bits
    print()
    for k in range(N):
        d = p - k
        if d != 0:
            pr = np.sin(np.pi*d)**2/np.sin(np.pi/N*d)**2/N**2
            print(k, np.round(pr, 5))


    # p = 5.7
    #
    # outcomes =  [(6, 0.74026), (5, 0.1388), (7, 0.04283), (4, 0.02668), (0, 0.01658), (3, 0.01343), (1, 0.01104), (2, 0.01037)]
    #
    # 0 0.01658
    # 1 0.01104
    # 2 0.01037
    # 3 0.01343
    # 4 0.02668
    # 5 0.1388
    # 6 0.74026
    # 7 0.04283