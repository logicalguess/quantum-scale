# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import math
import numpy as np

import util


def cry(theta, qc, q_control, q_target):
    qc.ry(theta/2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta/2, q_target)
    qc.cx(q_control, q_target)


def ccry(theta, qc, q_control_1, q_control_2, q_target):
    qc.ry(theta/2, q_target)
    qc.ccx(q_control_1, q_control_2, q_target)
    qc.ry(-theta/2, q_target)
    qc.ccx(q_control_1, q_control_2, q_target)


a = 2.0
b = 3.0
c = 5.0


def build_circuit():
    q = QuantumRegister(2)
    w = QuantumRegister(1)

    qc = QuantumCircuit(q, w)

    for i in range(len(q)):
        qc.h(q[i])

    # qc.x(q[0])
    # qc.x(q[1])

    qc.ry(2*c, w[0])
    cry(2*(4*a + 2*b), qc, q[0], w[0])
    ccry(2*4*a, qc, q[0], q[1], w[0])
    cry(2*(a + b), qc, q[1], w[0])

    return qc, None, None


if __name__ == "__main__":

    qc, _, _ = build_circuit()

    # from qiskit.tools.visualization import plot_circuit
    # plot_circuit(qc)

    hist = util.get_probs((qc, None, None), 'sim')
    print("Probabilities:", hist)

    # visualization.plot_histogram(hist)

    sin_i = [np.math.sin(a*i*i + b*i + c)*np.math.sin(a*i*i + b*i + c)/4 for i in range(0, 4)]
    print('sin^2(p(i))/4:', dict(zip(range(0,4), np.round(sin_i, 5))))
