import math
import numpy as np

# importing QISKit
from qiskit import QuantumCircuit, QuantumRegister
from qiskit.tools import visualization

import util


def cry(theta, qc, q_control, q_target):
    qc.ry(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.ry(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def crz(theta, qc, q_control, q_target):
    qc.rz(theta / 2, q_target)
    qc.cx(q_control, q_target)
    qc.rz(-theta / 2, q_target)
    qc.cx(q_control, q_target)


def is_bit_not_set(m, k):
    return not (m & (1 << k))


def controlled_ry(qc, times, ctrl, anc, tgt):
    return util.controlled(qc, ctrl, anc, tgt, c_gate = lambda qc, c, t: cry(1/2**n_ctrl_bits * 2*np.pi*times, qc, c, t))


def on_match_ry(n, m, qc, times, q, a, t):
    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[i])

    controlled_ry(qc, times, q, a, t)

    for i in range(0, n):
        if is_bit_not_set(m, i):
            qc.x(q[i])


def iqft(qc, q):
    for j in range(len(q))[::-1]:
        qc.h(q[j])
        for k in range(j)[::-1]:
            crz(-np.pi / float(2 ** (j - k)), qc, q[j], q[k])


def combine(n_bits, probs):

    combined = {}
    for b, c in probs.items():
        print(b, c)
        key = int(b[0:n_bits], 2)
        combined[key] = combined.get(key, 0) + c
    return combined


def process_estimates(estimates):
    rounded = dict(
        map(lambda item: (item[0], np.round(item[1], 5)), estimates.items()))
    ordered = sorted(rounded.items(), key=lambda x: x[1], reverse=True)
    print("outcomes = ", ordered)
    return ordered


def build_circuit(n_qbits, c_qbits, partition):
    t = QuantumRegister(n_qbits)
    a = QuantumRegister(1)
    e = QuantumRegister(n_qbits)
    c = QuantumRegister(c_qbits)
    qc = QuantumCircuit(c, t, a, e)

    for i in range(n_qbits):
        qc.h(t[i])

    for i in range(c_qbits):
        qc.h(c[i])

    qc.rx(np.pi/2, a[0])
    qc.z(a[0])
    qc.x(a[0])

    # controlled rotations
    for i in range(c_qbits):
        for k in range(2**n_qbits):
            on_match_ry(n_qbits, k, qc, 2**(i+1)*partition[k], [t[i] for i in range(0, len(t))] + [c[i]], e, a)


    # inverse fourier to retrieve best approximations
    iqft(qc, [c[i] for i in range(c_qbits)])

    return qc


if __name__ == "__main__":
    n_ctrl_bits = 3
    n_tgt_bits = 4

    rs = np.random.random(2**n_ctrl_bits)
    p = rs/rs.sum()

    freqs = {}
    N = 2**n_tgt_bits
    for i, v in enumerate(p):
        freqs[i] = int(np.round(v*N))
    s = sum(freqs.values())
    if s < N:
        freqs[0] = freqs[0] + N - s
    elif s > N:
        km = max(freqs, key=freqs.get)
        freqs[km] = freqs[km] - s + N

    partition = {}
    idx = 0
    counter = 0
    for k in range(2**n_tgt_bits):
        if counter == freqs[idx]:
            counter = 0
            idx = idx + 1
            while freqs[idx] == 0:
                idx = idx + 1

        partition[k] = idx
        counter = counter + 1

    qc = build_circuit(n_tgt_bits, n_ctrl_bits, partition)
    # visualization.plot_circuit(qc)

    probs = util.get_probs((qc, None, None), 'sim')
    visualization.plot_histogram(probs)

    # print(probs)

    estimates = combine(n_ctrl_bits, probs)
    outcomes = process_estimates(estimates)
    counts = dict(
        map(lambda item: (item[0], int(round(item[1]*2**n_tgt_bits))), estimates.items()))

    print("out -> #in : ", sorted(counts.items(), key=lambda x: x[0], reverse=False))

    ps = dict(
        map(lambda item: (item[0], np.round(item[1], 4)), enumerate(p)))

    print()
    print("Initial probabilities and counts:")
    print("p = ", sorted(ps.items(), key=lambda x: x[1], reverse=True))
    print("counts", freqs)

    # outcomes =  [(5, 0.21868), (0, 0.18744), (7, 0.18744), (3, 0.17182), (4, 0.12496), (2, 0.06248), (6, 0.03124), (1, 0.01562)]
    # out -> #in :  [(0, 12), (1, 1), (2, 4), (3, 11), (4, 8), (5, 14), (6, 2), (7, 12)]
    #
    # Initial probabilities and counts:
    # p =  [(5, 0.2325), (0, 0.1946), (7, 0.1915), (3, 0.168), (4, 0.1245), (2, 0.0551), (6, 0.0255), (1, 0.0081)]
    # counts {0: 12, 1: 1, 2: 4, 3: 11, 4: 8, 5: 14, 6: 2, 7: 12}

