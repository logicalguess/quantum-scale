import numpy as np
import math

from circuit_util import controlled_ry

from quantum.python.quantum_dictionary.quantum_dictionary import QDictionary

class QSumDictionary(QDictionary):
    # A Quantum Dictionary built from a function

    @staticmethod
    def populate(f, circuit, key, value, ancilla, extra):
        # controlled rotations only n powers of 2
        for i in range(len(value)):
            for j in range(len(key)):
                controlled_ry(circuit, 1/2 ** len(value) * 2 * np.pi * 2 ** (i + 1) * f[len(key) - 1 - j],
                              [key[j], value[i]], extra, ancilla[0])  # sum on powers of 2

    def __init__(self, key_bits, value_bits, f):
        QDictionary.__init__(self, key_bits, value_bits, 0, f, QSumDictionary.populate)

    def get_sum(self):
        self.get_value(2**self.key_bits - 1)


if __name__ == "__main__":
    f = [12, 3, -1]

    n_key = len(f)
    n_value = math.ceil(np.log2(sum(f)))

    qd = QSumDictionary(n_key, n_value, f)
    # qd.get_value(3)
    qd.get_sum()
