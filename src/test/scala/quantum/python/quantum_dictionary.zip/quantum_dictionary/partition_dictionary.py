import numpy as np

from circuit_util import controlled_ry

from quantum.python.quantum_dictionary.quantum_dictionary import QDictionary

class QPartitionDictionary(QDictionary):
    # A Quantum Dictionary built from a function

    @staticmethod
    def populate(f, circuit, key, value, ancilla, extra):
        # controlled rotations only n powers of 2
        for i in range(len(value)):
            for j in range(len(key)):
                controlled_ry(circuit, 1/2 ** len(value) * 2 * np.pi * 2 ** (i + 1) * f[len(key) - 1 - j],
                              [key[j], value[i]], extra, ancilla[0])  # sum on powers of 2


    @staticmethod
    def unpopulate(f, circuit, key, value, ancilla, extra):
        # controlled rotations only n powers of 2
        for i in range(len(value)):
            for j in range(len(key)):
                controlled_ry(circuit, -1/2 ** len(value) * 2 * np.pi * 2 ** (i + 1) * f[len(key) - 1 - j],
                              [key[j], value[i]], extra, ancilla[0])  # sum on powers of 2

    def __init__(self, key_bits, value_bits, precision_bits, f):
        QDictionary.__init__(self, key_bits, value_bits, precision_bits, f, QPartitionDictionary.populate, QPartitionDictionary.unpopulate)

    def get_count(self):
        return QDictionary.get_count(self) - 1


if __name__ == "__main__":
    f = [1, 1, -1] # 2
    # f = [2, 2, 2, -3] # 0

    n_key = len(f)
    n_value = 3
    n_precision = 5

    qd = QPartitionDictionary(n_key, n_value, n_precision, f)
    print(qd.get_count())
