import numpy as np

from circuit_util import on_match_ry

from quantum.python.quantum_dictionary.quantum_dictionary import QDictionary

class QFunctionDictionary(QDictionary):
    # A Quantum Dictionary built from a function

    @staticmethod
    def populate(f, circuit, key, value, ancilla, extra):
        for i in range(len(value)):
            for k in range(2**len(key)):
                on_match_ry(len(key), k, circuit, 1/2 ** len(value) * 2 * np.pi * 2 ** (i+1) * f[k], [key[j] for j in range(0, len(key))] + [value[i]], extra, ancilla)


    def __init__(self, key_bits, value_bits, f):
        QDictionary.__init__(self, key_bits, value_bits, 0, f, QFunctionDictionary.populate)


if __name__ == "__main__":

    n_key = 2
    n_value = 4

    f = [k*k for k in range(2**n_key)]

    qd = QFunctionDictionary(n_key, n_value, f)
    qd.get_value(3)
